class RickNMortyCharacterModel {
  String name = "";
  String status = "";
  String species = "";
  String gender = "";
  String image = "";
  String location = "";
  String dimension = "";

  RickNMortyCharacterModel({
    this.name = "",
    this.status = "",
    this.species = "",
    this.gender = "",
    this.image = "",
    this.location = "",
    this.dimension = "",
  });

  RickNMortyCharacterModel.fromJson(Map<String, dynamic> json) {
    try {
      name = json['name'];
      status = json['status'];
      species = json['species'];
      gender = json['gender'];
      dimension = json['origin']['name'];
      location = json['location']['name'];
      image = json['image'];
    } catch (e) {
      return;
    }
  }
}
