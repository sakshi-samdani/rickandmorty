import 'dart:convert';

import 'package:flutter/material.dart';

import 'character_details_widget.dart';
import 'rick_n_morty_character_model.dart';
import 'package:http/http.dart' as http;

class RickAndMortyChacactersListWidget extends StatefulWidget {
  const RickAndMortyChacactersListWidget({
    Key? key,
  }) : super(key: key);

  @override
  _RickAndMortyChacactersListWidgetState createState() =>
      _RickAndMortyChacactersListWidgetState();
}

class _RickAndMortyChacactersListWidgetState
    extends State<RickAndMortyChacactersListWidget> {
  final ValueNotifier<bool> _isLoading = ValueNotifier(false);
  final ValueNotifier<bool> _isError = ValueNotifier(false);

  List<RickNMortyCharacterModel>? _characterLists;

  @override
  void initState() {
    super.initState();
    fetchData();
  }

  fetchData() async {
    try {
      _isLoading.value = true;
      final response = await http
          .get(Uri.parse('https://rickandmortyapi.com/api/character/?page=1'));

      if (response.statusCode == 200) {
        _isError.value = false;
        var jsonResponse = json.decode(response.body)['results'];
        _characterLists = jsonResponse
            .map<RickNMortyCharacterModel>(
                (item) => RickNMortyCharacterModel.fromJson(item))
            .toList();
      } else {
        _isError.value = true;
        _characterLists = null;
        throw Exception('Failed to load data');
      }
    } catch (e) {
      _isError.value = true;
    } finally {
      _isLoading.value = false;
    }
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<bool>(
      valueListenable: _isLoading,
      builder: (context, isLoading, child) => isLoading
          ? const Center(
              child: CircularProgressIndicator(),
            )
          : child!,
      child: ValueListenableBuilder<bool>(
        valueListenable: _isError,
        builder: (context, hasError, child) => hasError
            ? const Center(
                child: Text(
                  'Something went Wrong..!!',
                  style: TextStyle(
                    color: Colors.red,
                    fontSize: 36,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              )
            : ListView.separated(
                separatorBuilder: (context, index) => const Divider(),
                itemBuilder: (context, index) => GestureDetector(
                  onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => CharacterDetailsWidget(
                          rickNMortyCharacter: _characterLists![index],
                        ),
                      )),
                  child: Container(
                    padding: const EdgeInsets.all(5.0),
                    child: Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(5.0),
                          child: Image.network(
                            _characterLists![index].image,
                            height: 50,
                            width: 50,
                          ),
                        ),
                        Expanded(
                          child: Container(
                            padding: const EdgeInsets.all(5.0),
                            child: Column(
                              children: [
                                Center(
                                    child: Text(
                                  _characterLists![index].name,
                                  style: const TextStyle(
                                      fontWeight: FontWeight.bold),
                                )),
                                Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Flexible(
                                      flex: 1,
                                      child: Row(
                                        children: [
                                          const Text(
                                            'Location ',
                                            style: TextStyle(
                                              fontSize: 16,
                                              color: Colors.black,
                                              fontWeight: FontWeight.bold,
                                            ),
                                          ),
                                          Expanded(
                                            child: Text(
                                              _characterLists![index].location,
                                              style: const TextStyle(
                                                fontSize: 16,
                                                color: Colors.black,
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    const SizedBox(width: 20),
                                    Flexible(
                                      flex: 1,
                                      child: Row(
                                        children: [
                                          const Text(
                                            'Species ',
                                            style: TextStyle(
                                              fontSize: 16,
                                              color: Colors.black,
                                              fontWeight: FontWeight.bold,
                                            ),
                                          ),
                                          Expanded(
                                            child: Text(
                                              _characterLists![index].species,
                                              style: const TextStyle(
                                                fontSize: 16,
                                                color: Colors.black,
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    )
                                  ],
                                ),
                              ],
                            ),
                          ),
                        )
                      ],
                    ),
                  ),
                ),
                itemCount: _characterLists!.length,
              ),
      ),
    );
  }
}
