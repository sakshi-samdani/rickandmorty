import 'package:flutter/material.dart';

import 'rick_n_morty_character_model.dart';

class CharacterDetailsWidget extends StatelessWidget {
  final RickNMortyCharacterModel rickNMortyCharacter;
  const CharacterDetailsWidget({
    Key? key,
    required this.rickNMortyCharacter,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(rickNMortyCharacter.name),
      ),
      body: Column(
        children: [
          Container(
              padding: const EdgeInsets.all(5.0),
              child: Image.network(rickNMortyCharacter.image)),
          const SizedBox(height: 10),
          characteristic('Status ', rickNMortyCharacter.status),
          characteristic('Gender ', rickNMortyCharacter.gender),
          characteristic('Species ', rickNMortyCharacter.species),
          characteristic('Location ', rickNMortyCharacter.location),
          characteristic('Dimension ', rickNMortyCharacter.dimension),
        ],
      ),
    );
  }

  Widget characteristic(String title, String text) {
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            const SizedBox(width: 10),
            Expanded(
              flex: 1,
              child: Text(
                title,
                //textAlign: TextAlign.end,
                style: const TextStyle(
                  fontSize: 16,
                  color: Colors.black,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              flex: 2,
              child: Text(
                text,
                style: const TextStyle(
                  fontSize: 16,
                  color: Colors.black,
                ),
              ),
            ),
            const SizedBox(width: 10),
          ],
        ),
        const Divider(),
      ],
    );
  }
}
